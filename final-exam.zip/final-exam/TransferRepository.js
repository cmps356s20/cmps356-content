const fs = require('fs-extra');
const path = require('path');

//ToDo : Implement the TransferRepository methods using MongoDB
class TransferRepository {
    async getColleges() {
        let colleges = await fs.readJSON('./data/qu-programs.json');
        colleges = colleges.map(c => { return {code: c.code, name: c.name} });
        return colleges;
    }

    async getPrograms(collegeCode) {
        const colleges = await fs.readJSON('./data/qu-programs.json');
        const programs = colleges.find(x => x.code === collegeCode).programs;
        return programs;
    }

    async addTransfer(transfer) {
        let transfers = await fs.readJSON('./data/transfer.json');
        const collegeName = (await this.getColleges()).find(x => x.code === transfer.collegeCode).name;
        const programName = (await this.getPrograms(transfer.collegeCode)).find(x => x.code === transfer.programCode).name;
        const foundIndex = transfers.findIndex(x => x.studentId == transfer.studentId);
        if (foundIndex >= 0)
            transfers.splice(foundIndex, 1);

        transfer.studentId = parseInt(transfer.studentId);
        transfer.collegeName = collegeName;
        transfer.programName = programName;
        transfer.status = "pending";
        transfers.push(transfer);
        return await fs.writeJSON('./data/transfer.json', transfers)
    }

    async updateTransfer(studentId, status) {
        let transfers = await fs.readJSON('./data/transfer.json');
        const foundIndex = transfers.findIndex(x => x.studentId === studentId);

        if (foundIndex >= 0)
            transfers[foundIndex].status = status;

        return await fs.writeJSON('./data/transfer.json', transfers)
    }

    async getTransfers(status) {
        let transfers = await fs.readJSON('./data/transfer.json');
        transfers = transfers.filter(t => t.status == status);
        return transfers;
    }

}

module.exports = new TransferRepository();