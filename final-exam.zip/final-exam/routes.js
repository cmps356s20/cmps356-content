const express = require('express');
const router = express.Router();

const transferService = require('./TransferService');

router.route('/colleges').get(transferService.getColleges);

router.route('/colleges/:collegeCode/programs').get(transferService.getPrograms);

router.route('/transfers/')
    .post(transferService.addTransfer)
    .put(transferService.updateTransfer);

router.route('/transfers/:status').get(transferService.getTransfers)

module.exports = router;