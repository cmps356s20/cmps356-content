const transferRepository = require('./TransferRepository');

//Implements the TransferService methods
class TransferService {

    //Add the TransferService methods
    //Handle get   /api/colleges/
    async getColleges(req, res) {
        try {
            const colleges = await transferRepository.getColleges();
            res.json(colleges);
        } catch (err) {
            console.log(err);
            res.status(500).send(err);
        }
    }

    //Handle get	/api/colleges/:collegeCode/programs
    async getPrograms(req, res) {
        try {
            const collegeCode = req.params.collegeCode;
            const programs = await transferRepository.getPrograms(collegeCode);
            res.json(programs);
        } catch (err) {
            console.log(err);
            res.status(500).send(err);
        }
    }

    //Handle post	/api/transfers/
    async addTransfer(req, res) {
        try {
            const transfer = req.body;
            await transferRepository.addTransfer(transfer);
            res.status(201).send("created");
        }
        catch (err) {
            console.log(err);
            res.status(500).send(err);
        }
    }

    //Handle put	/api/transfers/
    async updateTransfer(req, res) {
        try {
            const studentId = parseInt(req.body.studentId);
            const status = req.body.status;
            await transferRepository.updateTransfer(studentId, status);
            res.status(201).send("updated");
        }
        catch (err) {
            console.log(err);
            res.status(500).send(err);
        }
    }

    //Handle get	/api/transfers/
    async getTransfers(req, res) {
        try {
            const status = req.params.status;
            const transfers = await transferRepository.getTransfers(status);
            res.json(transfers);
        } catch (err) {
            console.log(err);
            res.status(500).send(err);
        }
    }

}

module.exports = new TransferService();